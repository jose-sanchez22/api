# Proyecto SNMP CRUD

Este proyecto captura traps SNMP de routers Cisco (c7200, C3725, etc.), los almacena y permite gestionarlos vía API REST y una interfaz web responsiva.

## Componentes
- **Backend:** Flask + pysnmp para CRUD y escucha de traps.
- **Frontend:** HTML + Bootstrap para visualización y gestión.
- **Postman:** Colección para probar la API.

## Instalación
```bash
cd backend
pip install -r requirements.txt
python app.py
```

## API REST
- `GET /api/traps` → Lista todas las traps.
- `POST /api/traps` → Agrega trap manualmente.
- `PUT /api/traps/<id>` → Actualiza trap.
- `DELETE /api/traps/<id>` → Elimina trap.

## SNMP en Cisco
Ejemplo en router:
```
snmp-server community public RO
snmp-server host 192.168.100.3 public
snmp-server enable traps
```
